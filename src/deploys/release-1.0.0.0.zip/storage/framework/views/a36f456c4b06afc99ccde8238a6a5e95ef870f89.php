<?php $__env->startSection('title', 'Página principal'); ?>

<?php $__env->startSection('content'); ?>
<div class="row row-md mb-2">
    <div class="col-md-12">
        <p>Página principal.</p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codeando/github/Juridico/src/comisaria/resources/views/init.blade.php ENDPATH**/ ?>