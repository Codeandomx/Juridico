@extends('layouts.main_layout')

@section('title', 'Página principal')

@section('content')
<div class="row row-md mb-2">
    <div class="col-md-12">
        <p>Página recursos humanos.</p>
    </div>
</div>
@endsection
