$('#chart-easy').easyPieChart({
    animate: 2000,
    size: 100,
    lineWidth: 5,
    barColor: '#f44236',
    trackColor: '#ddd',
    scaleColor: false,
});

$('#chart-easy-2').easyPieChart({
    animate: 2000,
    size: 100,
    lineWidth: 5,
    barColor: '#43b968',
    trackColor: '#ddd',
});

$('#chart-easy-3').easyPieChart({
    animate: 2000,
    size: 100,
    lineWidth: 10,
    barColor: '#a567e2',
    trackColor: '#ddd',
    scaleColor: false,
});

$('#chart-easy-4').easyPieChart({
    animate: 2000,
    size: 100,
    lineWidth: 5,
    barColor: '#20b9ae',
    trackColor: '#ddd',
});